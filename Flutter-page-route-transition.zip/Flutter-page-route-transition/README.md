# Flutter page route transition

A Flutter application showing different ways of animating page route transition. For more info check out my [blog](https://medium.com/flutter-community/everything-you-need-to-know-about-flutter-page-route-transition-9ef5c1b32823)

<img src ="https://github.com/divyanshub024/Flutter-page-route-transition/blob/master/art/route_transition.gif" />
